const USER_RE = /^[a-zA-Z0-9._-]{1,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const enc = new TextEncoder();
const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {
  status, headers: {"content-type":"application/json; charset=utf-8","cache-control":"no-store",...headers}
});
const randomId = (n=24) => {
  const b = crypto.getRandomValues(new Uint8Array(n));
  return [...b].map(x=>x.toString(16).padStart(2,"0")).join("");
};
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
const unb64 = s => Uint8Array.from(atob(s.replace(/-/g,"+").replace(/_/g,"/")+"===".slice((s.length+3)%4)),c=>c.charCodeAt(0));
async function sha(text) { return b64(await crypto.subtle.digest("SHA-256",enc.encode(text))); }
async function passwordHash(password, salt=randomId(16)) {
  const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:enc.encode(salt),iterations:210000,hash:"SHA-256"},key,256);
  return `pbkdf2$210000$${salt}$${b64(bits)}`;
}
async function passwordVerify(password, stored) {
  const [kind,it,salt,expected]=String(stored).split("$");
  if(kind!=="pbkdf2" || !salt || !expected) return false;
  const actual=await passwordHash(password,salt);
  return actual===stored;
}
async function readBody(req){try{return await req.json()}catch{return {}}}
function cookie(token,age=60*60*24*14){return `shiz_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${age}`;}
function getCookie(req,name){return (req.headers.get("Cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(name+"="))?.slice(name.length+1)||"";}
async function currentAccount(req,env){
  const token=getCookie(req,"shiz_session"); if(!token) return null;
  const hash=await sha(token), now=Math.floor(Date.now()/1000);
  const row=await env.DB.prepare("SELECT a.id,a.email FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.expires_at>?").bind(hash,now).first();
  return row||null;
}
function validUsername(u){return typeof u==="string" && USER_RE.test(u);}
function safeUser(u){return {username:u.username,display_name:u.display_name,bio:u.bio,avatar_url:u.avatar_url,views:u.views,created_at:u.created_at};}
async function createSession(accountId,env){
  const token=randomId(32), hash=await sha(token), expiry=Math.floor(Date.now()/1000)+60*60*24*14;
  await env.DB.prepare("INSERT INTO sessions(token_hash,account_id,expires_at) VALUES(?,?,?)").bind(hash,accountId,expiry).run();
  return token;
}
async function api(req,env,url){
  const p=url.pathname,m=req.method;
  if(p==="/api/health") return json({ok:true});
  if(p==="/api/register" && m==="POST"){
    const d=await readBody(req),email=String(d.email||"").trim().toLowerCase(),password=String(d.password||"");
    if(!EMAIL_RE.test(email)||email.length>254) return json({error:"Vul een geldig e-mailadres in."},400);
    if(password.length<10||password.length>128) return json({error:"Je wachtwoord moet minimaal 10 tekens bevatten."},400);
    const id=randomId(16),hash=await passwordHash(password);
    try{
      await env.DB.prepare("INSERT INTO accounts(id,email,password_hash) VALUES(?,?,?)").bind(id,email,hash).run();
      const token=await createSession(id,env);
      return json({ok:true,email},201,{"set-cookie":cookie(token)});
    }catch(e){return json({error:"Dit e-mailadres heeft al een account."},409);}
  }
  if(p==="/api/login" && m==="POST"){
    const d=await readBody(req),email=String(d.email||"").trim().toLowerCase(),password=String(d.password||"");
    const account=await env.DB.prepare("SELECT id,email,password_hash FROM accounts WHERE email=? COLLATE NOCASE").bind(email).first();
    if(!account || !await passwordVerify(password,account.password_hash)) return json({error:"E-mailadres of wachtwoord klopt niet."},401);
    const token=await createSession(account.id,env);
    return json({ok:true,email:account.email},200,{"set-cookie":cookie(token)});
  }
  if(p==="/api/logout" && m==="POST"){
    const token=getCookie(req,"shiz_session");
    if(token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha(token)).run();
    return json({ok:true},200,{"set-cookie":cookie("",0)});
  }
  if(p==="/api/me" && m==="GET"){
    const account=await currentAccount(req,env); if(!account) return json({account:null,user:null});
    const user=await env.DB.prepare("SELECT username,display_name,bio,avatar_url,views,created_at FROM users WHERE account_id=?").bind(account.id).first();
    return json({account:{email:account.email},user:user||null});
  }
  if(p==="/api/claim" && m==="POST"){
    const account=await currentAccount(req,env); if(!account) return json({error:"Log eerst in om een username te claimen."},401);
    const already=await env.DB.prepare("SELECT username FROM users WHERE account_id=?").bind(account.id).first();
    if(already) return json({error:`Je hebt al @${already.username}. Eén username per account.`},409);
    const d=await readBody(req),username=String(d.username||"").trim();
    if(!validUsername(username)) return json({error:"Gebruik 1–20 letters, cijfers, punten, _ of -."},400);
    try{
      await env.DB.prepare("INSERT INTO users(id,account_id,username,display_name) VALUES(?,?,?,?)").bind(randomId(16),account.id,username,username).run();
      return json({ok:true,username},201);
    }catch(e){return json({error:"Deze username is al geclaimd. Kies een andere."},409);}
  }
  if(p==="/api/claims" && m==="GET"){
    const {results=[]}=await env.DB.prepare("SELECT username,views FROM users ORDER BY created_at DESC LIMIT 30").all();
    return json({claims:results});
  }
  if(p.startsWith("/api/profile/") && m==="GET"){
    const name=decodeURIComponent(p.slice("/api/profile/".length));
    if(!validUsername(name)) return json({error:"Profiel niet gevonden."},404);
    await env.DB.prepare("UPDATE users SET views=views+1 WHERE username=? COLLATE NOCASE").bind(name).run();
    const user=await env.DB.prepare("SELECT username,display_name,bio,avatar_url,views,created_at FROM users WHERE username=? COLLATE NOCASE").bind(name).first();
    return user?json({user:safeUser(user)}):json({error:"Profiel niet gevonden."},404);
  }
  if(p==="/api/profile" && m==="PATCH"){
    const account=await currentAccount(req,env); if(!account) return json({error:"Log opnieuw in."},401);
    const d=await readBody(req),display=String(d.display_name||"").slice(0,40),bio=String(d.bio||"").slice(0,240),avatar=String(d.avatar_url||"").slice(0,500);
    if(avatar && !/^https:\/\/[^ ]+/i.test(avatar)) return json({error:"Profielfoto moet een https-link zijn."},400);
    const result=await env.DB.prepare("UPDATE users SET display_name=?,bio=?,avatar_url=?,updated_at=datetime('now') WHERE account_id=?").bind(display,bio,avatar,account.id).run();
    if(!result.meta.changes) return json({error:"Claim eerst een username."},400);
    return json({ok:true});
  }
  if(p==="/api/owner/login" && m==="POST"){
    if(!env.OWNER_PASSWORD||!env.SESSION_SECRET) return json({error:"Owner secrets ontbreken in Cloudflare."},503);
    const d=await readBody(req); if(String(d.password||"")!==env.OWNER_PASSWORD) return json({error:"Onjuist owner-wachtwoord."},401);
    const token=randomId(32),hash=await sha(token),expiry=Math.floor(Date.now()/1000)+8*3600;
    await env.DB.prepare("INSERT INTO sessions(token_hash,account_id,expires_at) VALUES(?,?,?)").bind(hash,"OWNER",expiry).run().catch(()=>{});
    // Owner uses a separate signed cookie, handled in owner routes below.
    const payload=`owner.${expiry}.${randomId(16)}`,sig=await hmac(payload,env.SESSION_SECRET);
    return json({ok:true},200,{"set-cookie":`shiz_owner=${payload}.${sig}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`});
  }
  if(p.startsWith("/api/owner/")){
    if(!await ownerValid(req,env)) return json({error:"Geen toegang."},401);
    if(p==="/api/owner/users" && m==="GET"){
      const {results=[]}=await env.DB.prepare("SELECT u.username,u.display_name,u.bio,u.avatar_url,u.views,u.created_at,a.email FROM users u JOIN accounts a ON a.id=u.account_id ORDER BY u.created_at DESC").all();
      return json({users:results});
    }
    if(p==="/api/owner/summary" && m==="GET"){
      const row=await env.DB.prepare("SELECT COUNT(*) AS users,COALESCE(SUM(views),0) AS views FROM users").first();return json(row);
    }
    const match=p.match(/^\\/api\\/owner\\/users\\/([^/]+)$/);
    if(match && m==="DELETE"){
      const result=await env.DB.prepare("DELETE FROM users WHERE username=? COLLATE NOCASE").bind(decodeURIComponent(match[1])).run();
      return result.meta.changes?json({ok:true}):json({error:"Niet gevonden."},404);
    }
    if(match && m==="PATCH"){
      const old=decodeURIComponent(match[1]),d=await readBody(req),display=String(d.display_name||"").slice(0,40),bio=String(d.bio||"").slice(0,240),avatar=String(d.avatar_url||"").slice(0,500);
      try{const r=await env.DB.prepare("UPDATE users SET display_name=?,bio=?,avatar_url=?,updated_at=datetime('now') WHERE username=? COLLATE NOCASE").bind(display,bio,avatar,old).run();return r.meta.changes?json({ok:true}):json({error:"Niet gevonden."},404);}catch{return json({error:"Opslaan mislukt."},400);}
    }
  }
  return json({error:"Niet gevonden."},404);
}
async function hmac(text,secret){const key=await crypto.subtle.importKey("raw",enc.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return b64(await crypto.subtle.sign("HMAC",key,enc.encode(text)));}
async function ownerValid(req,env){
  const raw=getCookie(req,"shiz_owner").split(".");if(raw.length!==4||raw[0]!=="owner"||Number(raw[1])<Date.now()/1000)return false;
  return (await hmac(raw.slice(0,3).join("."),env.SESSION_SECRET||""))===raw[3];
}
export default {async fetch(req,env){
  const url=new URL(req.url);
  if(url.pathname.startsWith("/api/")){try{return await api(req,env,url)}catch(e){return json({error:"Serverfout. Controleer D1-migratie en Cloudflare-instellingen."},500)}}
  if(url.pathname==="/owner"||url.pathname==="/owner/")return env.ASSETS.fetch(new Request(new URL("/owner.html",req.url),req));
  if(url.pathname==="/")return env.ASSETS.fetch(new Request(new URL("/index.html",req.url),req));
  const asset=await env.ASSETS.fetch(req);if(asset.status!==404)return asset;
  if(url.pathname.split("/").filter(Boolean).length===1)return env.ASSETS.fetch(new Request(new URL("/profile.html",req.url),req));
  return new Response("Not found",{status:404});
}};
