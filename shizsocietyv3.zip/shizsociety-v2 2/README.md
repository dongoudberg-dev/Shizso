# Shizsociety v2

## Included
- Email/password registration and login
- Password hashing with PBKDF2 (210,000 iterations)
- Persistent HttpOnly session cookies
- Exactly one username per account (D1 UNIQUE constraints)
- Globally unique usernames (case-insensitive)
- Public profile routes: `https://your-domain/username`
- Profile editor
- Owner login and member list/delete

## Cloudflare setup
1. Create a D1 database named `shizsociety`.
2. Copy its Database ID into `wrangler.jsonc` replacing `REPLACE_WITH_YOUR_D1_DATABASE_ID`.
3. In Workers & Pages > your Worker > Settings > Variables, add secrets:
   - `OWNER_PASSWORD`: a strong, unique owner password
   - `SESSION_SECRET`: a long random secret (32+ random characters)
4. Run the migration from a terminal:
   `npx wrangler d1 migrations apply shizsociety --remote`
5. Deploy from the project folder:
   `npm install`
   `npx wrangler deploy`

## If using the ZIP-only GitHub repository
Upload this archive to the repository root. In Cloudflare Workers Builds:
- Build command: `unzip -o shizsociety-full-cloudflare.zip -d . && cd shizsociety && npm install`
- Deploy command: `cd shizsociety && npx wrangler deploy`
Note: Workers Builds may need a build command that installs dependencies before the deploy command. Database ID and secrets must be configured before a successful live deployment.

## Important
This starter does not include email verification or password reset email delivery. Do not reuse a personal password. Configure a custom domain and test registration/profile/owner access before sharing publicly.
