# Shizsociety — full Cloudflare Worker + D1

This is the real backend package, not a browser-only demo.

## Requirements
- Cloudflare account
- Node.js + npm on a computer (or a GitHub-connected Cloudflare Workers build environment)
- Cloudflare D1 database

## Deploy (Wrangler)
1. Extract this ZIP and open a terminal in this folder.
2. Run `npm install`
3. Run `npx wrangler d1 create shizsociety-db`
4. Copy the returned database ID into `wrangler.jsonc`, replacing `REPLACE_WITH_YOUR_D1_DATABASE_ID`.
5. Run `npx wrangler d1 migrations apply shizsociety-db --remote`
6. Set a strong owner password: `npx wrangler secret put OWNER_PASSWORD`
7. Set a long random session secret: `npx wrangler secret put SESSION_SECRET`
8. Run `npx wrangler deploy`

## Features
- Globally unique usernames enforced by D1 primary key (case-insensitive)
- 1–20 character username validation
- Public profile routes: `https://YOUR-DOMAIN/<username>`
- Owner panel: `https://YOUR-DOMAIN/owner`
- Owner can edit/delete usernames, display names, bios, avatar URLs and view counts
- Owner session uses a signed, HttpOnly, Secure, SameSite=Strict cookie

## Important
Cloudflare's simple **Upload your static files** flow only deploys static assets. It cannot provision this Worker backend or D1 database. Use Wrangler deploy or connect this repository as a Worker project. Do not upload this ZIP as a static-only site if you want real global claims and the owner dashboard.
