const COOKIE = "shiz_owner";
const USER_RE = /^[a-zA-Z0-9._-]{1,20}$/;

function json(data, status=200, headers={}) {
  return new Response(JSON.stringify(data), {
    status, headers: { "content-type":"application/json; charset=utf-8", "cache-control":"no-store", ...headers }
  });
}
function b64url(bytes) {
  let s = btoa(String.fromCharCode(...new Uint8Array(bytes)));
  return s.replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
function unb64url(s) {
  s=s.replace(/-/g,"+").replace(/_/g,"/");
  while(s.length%4) s+="=";
  return Uint8Array.from(atob(s), c=>c.charCodeAt(0));
}
async function sign(value, secret) {
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
  return b64url(await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(value)));
}
async function makeSession(secret) {
  const payload=b64url(new TextEncoder().encode(JSON.stringify({role:"owner",exp:Date.now()+8*60*60*1000})));
  return payload+"."+await sign(payload,secret);
}
async function validSession(request, secret) {
  const raw=(request.headers.get("Cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="));
  if(!raw) return false;
  const token=raw.slice(COOKIE.length+1), parts=token.split(".");
  if(parts.length!==2) return false;
  const expected=await sign(parts[0],secret);
  if(expected.length!==parts[1].length) return false;
  let diff=0; for(let i=0;i<expected.length;i++) diff|=expected.charCodeAt(i)^parts[1].charCodeAt(i);
  if(diff) return false;
  try { const p=JSON.parse(new TextDecoder().decode(unb64url(parts[0]))); return p.role==="owner"&&p.exp>Date.now(); } catch { return false; }
}
function cookie(value,maxAge=28800) {
  return `${COOKIE}=${value}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}
async function body(request) { try { return await request.json(); } catch { return {}; } }
function validUsername(name) { return typeof name==="string" && USER_RE.test(name); }
async function ownerOnly(request,env) { return await validSession(request,env.SESSION_SECRET||""); }

async function api(request,env,url) {
  const path=url.pathname, method=request.method;
  if(path==="/api/health") return json({ok:true,service:"Shizsociety"});
  if(path==="/api/claim" && method==="POST") {
    const data=await body(request), username=String(data.username||"").trim();
    if(!validUsername(username)) return json({error:"Username must be 1–20 characters: letters, numbers, dots, underscores or hyphens."},400);
    try {
      await env.DB.prepare("INSERT INTO users (username, display_name, bio, avatar_url, views, created_at, updated_at) VALUES (?, ?, '', '', 0, datetime('now'), datetime('now'))").bind(username,username).run();
      return json({ok:true,username},201);
    } catch(e) {
      const msg=String(e&&e.message||"");
      if(msg.toLowerCase().includes("unique") || msg.toLowerCase().includes("constraint")) return json({error:"That username has already been claimed."},409);
      return json({error:"Could not save the claim. Check the database setup."},500);
    }
  }
  if(path==="/api/claims" && method==="GET") {
    const {results=[]}=await env.DB.prepare("SELECT username, display_name, bio, avatar_url, views, created_at FROM users ORDER BY created_at DESC LIMIT 100").all();
    return json({claims:results});
  }
  if(path.startsWith("/api/profile/") && method==="GET") {
    const username=decodeURIComponent(path.slice("/api/profile/".length));
    if(!validUsername(username)) return json({error:"Invalid username."},400);
    await env.DB.prepare("UPDATE users SET views=views+1 WHERE username=? COLLATE NOCASE").bind(username).run();
    const user=await env.DB.prepare("SELECT username, display_name, bio, avatar_url, views, created_at, links_json FROM users WHERE username=? COLLATE NOCASE").bind(username).first();
    return user?json({user}):json({error:"Profile not found."},404);
  }
  if(path==="/api/owner/login" && method==="POST") {
    const data=await body(request);
    if(!env.OWNER_PASSWORD || !env.SESSION_SECRET) return json({error:"Owner secrets are not configured yet."},503);
    const supplied=String(data.password||"");
    if(supplied!==env.OWNER_PASSWORD) return json({error:"Incorrect password."},401);
    const token=await makeSession(env.SESSION_SECRET);
    return json({ok:true},200,{ "set-cookie":cookie(token) });
  }
  if(path==="/api/owner/logout" && method==="POST") return json({ok:true},200,{"set-cookie":cookie("",0)});
  if(path.startsWith("/api/owner/")) {
    if(!await ownerOnly(request,env)) return json({error:"Not authorized."},401);
    if(path==="/api/owner/summary" && method==="GET") {
      const row=await env.DB.prepare("SELECT COUNT(*) AS claims, COALESCE(SUM(views),0) AS views FROM users").first();
      return json(row||{claims:0,views:0});
    }
    if(path==="/api/owner/users" && method==="GET") {
      const {results=[]}=await env.DB.prepare("SELECT username, display_name, bio, avatar_url, views, created_at, links_json FROM users ORDER BY created_at DESC").all();
      return json({users:results});
    }
    const match=path.match(/^\/api\/owner\/users\/([^/]+)$/);
    if(match && method==="PATCH") {
      const oldName=decodeURIComponent(match[1]), data=await body(request);
      const newName=data.username===undefined?oldName:String(data.username).trim();
      if(!validUsername(newName)) return json({error:"Username must be 1–20 valid characters."},400);
      const display=String(data.display_name??newName).slice(0,40);
      const bio=String(data.bio??"").slice(0,240);
      const avatar=String(data.avatar_url??"").slice(0,500);
      const views=Math.max(0,Math.min(2147483647,Math.floor(Number(data.views??0)||0)));
      let links="[]";
      if(Array.isArray(data.links)) links=JSON.stringify(data.links.slice(0,8).map(x=>({label:String(x.label||"").slice(0,30),url:String(x.url||"").slice(0,300)})));
      try {
        const result=await env.DB.prepare("UPDATE users SET username=?, display_name=?, bio=?, avatar_url=?, views=?, links_json=?, updated_at=datetime('now') WHERE username=? COLLATE NOCASE")
          .bind(newName,display,bio,avatar,views,links,oldName).run();
        if(!result.meta.changes) return json({error:"User not found."},404);
        return json({ok:true});
      } catch(e) { return json({error:"That username is already taken."},409); }
    }
    if(match && method==="DELETE") {
      const result=await env.DB.prepare("DELETE FROM users WHERE username=? COLLATE NOCASE").bind(decodeURIComponent(match[1])).run();
      return result.meta.changes?json({ok:true}):json({error:"User not found."},404);
    }
  }
  return json({error:"Not found."},404);
}
export default {
  async fetch(request,env) {
    const url=new URL(request.url);
    if(url.pathname.startsWith("/api/")) {
      try { return await api(request,env,url); }
      catch(e) { return json({error:"Server error. Check D1 database and migrations."},500); }
    }
    if(url.pathname==="/owner" || url.pathname==="/owner/") return env.ASSETS.fetch(new Request(new URL("/owner.html",request.url),request));
    if(url.pathname==="/") return env.ASSETS.fetch(new Request(new URL("/index.html",request.url),request));
    const asset=await env.ASSETS.fetch(request);
    if(asset.status!==404) return asset;
    // Username routes are served by the profile shell; the API validates the actual profile.
    if(url.pathname.split("/").filter(Boolean).length===1) return env.ASSETS.fetch(new Request(new URL("/profile.html",request.url),request));
    return new Response("Not found",{status:404});
  }
};