
const path = decodeURIComponent(location.pathname.replace(/^\/|\/$/g, ""));
const title = document.querySelector("title");

async function load() {
  const card = document.querySelector("#profile");

  try {
    const response = await fetch(
      "/api/profile/" + encodeURIComponent(path),
      { cache: "no-store" }
    );

    const data = await response.json();

    if (!response.ok) {
      throw Error("API " + response.status + ": " + JSON.stringify(data));
    }

    const user = data.user;

    document.querySelector("#displayName").textContent =
      user.display_name || user.username;
    document.querySelector("#handle").textContent = "@" + user.username;
    document.querySelector("#bio").textContent =
      user.bio || "This profile is just getting started.";
    document.querySelector("#views").textContent =
      Number(user.views).toLocaleString();

    if (user.avatar_url) {
      const img = document.createElement("img");
      img.src = user.avatar_url;
      img.alt = "Profile avatar";
      document.querySelector("#avatar").replaceChildren(img);
    }

    const links = JSON.parse(user.links_json || "[]");
    const box = document.querySelector("#links");

    links.forEach(link => {
      try {
        const url = new URL(link.url);
        if (!["http:", "https:"].includes(url.protocol)) return;

        const a = document.createElement("a");
        a.href = url.href;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        a.textContent = link.label || url.hostname;
        box.append(a);
      } catch {}
    });

    title.textContent =
      (user.display_name || user.username) + " - Shizsociety";

  } catch (error) {
    card.innerHTML =
      "<h1>DEBUG ERROR</h1><p>" +
      String(error.message || error) +
      "</p><p>Path: " + path + "</p>";
  }
}

load();
